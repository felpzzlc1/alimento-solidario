# Alimento Solidário

Este projeto simula um deploy com GitHub Actions para fins acadêmicos.
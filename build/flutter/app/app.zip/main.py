import flet as ft

def main(page: ft.Page):
    page.title = "Alimento Solidário"
    page.add(ft.Text("Bem-vindo ao Alimento Solidário!"))

ft.app(target=main) 
